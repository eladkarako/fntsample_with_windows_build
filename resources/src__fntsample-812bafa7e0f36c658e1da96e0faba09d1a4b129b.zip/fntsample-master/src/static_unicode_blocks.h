/*
 * Author: Ievgenii Meshcheriakov <eugen@debian.org>
 * SPDX-License-Identifier: CC-PDDC
 */
#ifndef STATIC_UNICODE_BLOCKS_H
#define STATIC_UNICODE_BLOCKS_H
#include "unicode_blocks.h"

extern const struct unicode_block static_unicode_blocks[];

#endif
